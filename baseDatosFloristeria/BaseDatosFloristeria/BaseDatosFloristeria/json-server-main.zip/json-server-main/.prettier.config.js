export default {
  semi: false,
  singleQuote: true,
  trailingComma: 'all',
}
